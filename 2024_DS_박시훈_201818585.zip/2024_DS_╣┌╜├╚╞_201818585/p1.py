# 아래는 제시된 그래프입니다.
A = {
    0: [1, 2, 3],
    1: [0, 2, 4, 5],
    2: [0, 1, 6],
    3: [0],
    4: [1],
    5: [1],
    6: [2]
}

def bfs(A):
    """
    BFS(Breadth-First Search) 너비우선탐색을 사용하여 함수를 작성

    매개변수:
    A(dict): 그래프를 나타내는 딕셔너리

    반환값:
    answer: BFS로 탐색된 노드의 순서를 담은 리스트
    """
    answer = []      # bfs로 방문한 노드 순서를 저장할 리스트
    visited = set()  # 방문한 노드를 기록하기 위한 집합 set
    queue = [0]      # 큐를 리스트로 초기화, 큐는 탐색할 노드의 순서를 결정

    while queue:
        node = queue.pop(0)      # 리스트의 첫 번째 요소를 꺼냄
        if node not in visited:  # 만약 방문하지 않은 노드일 경우,
            answer.append(node)  # 해당 노드(요소)를 answer에 추가,
            visited.add(node)    # 방문한 노드를 기록.
            neighbors = A.get(node, [])  # 현재 탐색 중인 노드의 이웃 노드를 가져오되, 없을 시 빈 리스트 반환

            for neighbor in neighbors:       # 이웃한 노드들의 리스트를 순차적으로 방문하며 작업을 수행
                if neighbor not in visited:  # 만약 이웃한 노드가 아직 방문하지 않은 노드라면,
                    queue.append(neighbor)   # 큐에 이웃 노드를 추가하여 탐색 진행
    return answer

def dfs(A):
    """
    DFS(Depth-First Search) 깊이우선탐색을 사용하여 함수를 작성

    매개변수:
    A(dict): 그래프를 나타내는 딕셔너리

    반환값:
    answer: DFS로 탐색된 노드의 순서를 담은 리스트
    """
    answer = []      # dfs로 방문한 노드 순서를 저장할 리스트
    visited = set()  # 방문한 노드를 기록하기 위한 집합 set
    stack = [0]      # DFS를 위한 스택, 루트 노드인 0부터 시작
    visited_child = set()  # 이미 방문한 자식 노드를 기록하기 위한 집합(set), DFS 알고리즘에서 사이클을 방지하기 위해 추가
    visited_child.add(0)   #초기에 루트 노드를 방문한 것으로 표시, DFS 알고리즘이 시작될 때 루트 노드를 스택에 추가하고 방문한 것으로 처리

    while stack:
        node = stack.pop()  # 스택에서 노드를 꺼내옴
        if node not in visited:  # 만약 방문하지 않은 노드일 경우,
            answer.append(node)  # 해당 노드(요소)를 result에 추가,
            visited.add(node)    # 방문한 노드를 기록.
            neighbors = A.get(node, [])  # 현재 탐색 중인 노드의 이웃 노드를 가져오되, 없을 시 빈 리스트 반환

            for neighbor in reversed(neighbors):  # 스택에 넣을 때 역순으로 넣어야 DFS 순서를 유지함
                if neighbor not in visited and neighbor not in visited_child:  # 이웃 노드가 방문하지도 않았고, 방문한 자식노드도 아닐 경우,
                    stack.append(neighbor)        # 이웃 노드를 스택에 추가하여 탐색 진행
                    visited_child.add(neighbor)   # 이미 방문한 자식 노드에 기록
    return answer

# 아래는 체크함수입니다. 수정하실 필요 없습니다.
bfs_result = bfs(A)
dfs_result = dfs(A)

assert bfs_result == [0, 1, 2, 3, 4, 5, 6]
assert dfs_result == [0, 1, 4, 5, 2, 6, 3]
print('PASSED!')