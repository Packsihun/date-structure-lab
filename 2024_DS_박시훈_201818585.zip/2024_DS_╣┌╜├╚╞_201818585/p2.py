import sys

## 입력 받는 코드입니다. 수정할 필요 없습니다.
sys.stdin = open('case.txt')
N, M = list(map(int, input().split()))
print(N, M)
concerts = []
for v in range(N):
    values = list(map(int, input().split()))
    concerts.append(values)
# print(concerts)
# [[1, 0, 0, 1, 1, 0], [1, 0, 1, 1, 0, 0], [1, 1, 1, 1, 0, 1], [0, 1, 1, 0, 1, 1], [0, 1, 0, 0, 1, 0]]
###################################

def count_stages(concerts):
    """
    주어진 case.txt를 통해 독립적인 무대 공간의 개수를 계산하는 함수입니다.

    Parameters:
    concerts (list of list of int): 콘서트장의 약도, 2차원 리스트로 1은 펜스, 0은 무대 공간을 의미합니다.

    Returns:
    int: 독립적인 무대 공간의 개수
    """
    # 콘서트장의 크기
    N = len(concerts)     # N은 콘서트장의 행의 수
    M = len(concerts[0])  # M은 콘서트장의 열의 수
    
    # 방문 여부를 기록할 리스트
    visited = [[False] * M for _ in range(N)]  # 모든 칸은 처음에 방문되지 않았음을 나타내기 위해 False로 초기화
    
    def dfs(x, y):
        """
        깊이 우선 탐색을 통해 연결된 무대 공간을 탐색합니다.

        Parameters:
        x (int): 현재 탐색 중인 셀의 행 인덱스
        y (int): 현재 탐색 중인 셀의 열 인덱스
        """
        # 스택을 사용한 DFS 구현
        stack = [(x, y)]  # 스택을 초기화하고 시작 지점인 (x, y)를 추가
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # 이동할 수 있는 방향(상, 하, 좌, 우)을 정의
        
        while stack:  # 스택이 빌 때까지 반복
            cx, cy = stack.pop()  # 스택에서 좌표를 꺼내기
            for dx, dy in directions:  # 가능한 모든 방향에 대해 반복
                nx, ny = cx + dx, cy + dy  # 새로운 위치를 계산
                # 새로운 위치가 콘서트장의 범위 내에 있고, 방문하지 않았으며, 무대 공간인 경우에만 실행
                if 0 <= nx < N and 0 <= ny < M and not visited[nx][ny] and concerts[nx][ny] == 0: 
                    visited[nx][ny] = True  # 새로운 위치를 방문했음을 표시
                    stack.append((nx, ny))  # 새로운 위치를 스택에 추가하여 계속 탐색
    
    answer = 0  # 무대의 개수를 저장할 변수 answer을 초기화
    
    # 콘서트장의 각 셀을 검사하여 DFS를 시작할 지점 찾기
    for i in range(N): #  모든 셀에 대해 반복
        for j in range(M):  # 모든 셀에 대해 반복
            if concerts[i][j] == 0 and not visited[i][j]:  # 해당 셀이 무대 공간이고, 방문하지 않았다면 실행
                # 새로운 무대 공간을 찾음
                visited[i][j] = True  # 해당 셀을 방문했음을 표시
                dfs(i, j)  # 깊이 우선 탐색을 시작
                answer += 1  # 새로운 무대 공간을 찾을 때마다 answer를 1씩 증가
    
    return answer

print(count_stages(concerts))