# 프로젝트 문제 2번
input = ")))()"

def problem2(input):
    # 스택을 사용하여 괄호의 균형을 맞추기 위해 빈 리스트를 생성
    stack = []
    
    # 앞에 추가할 여는 괄호 수를 세기 위한 변수
    open_needed = 0
    
    # 입력된 문자열을 하나씩 확인
    for char in input:
        if char == '(':  # 여는 괄호일 경우 스택에 추가
            stack.append(char)
        elif char == ')':  # 닫는 괄호일 경우
            if stack:  # 스택에 매칭되는 여는 괄호가 있으면 pop
                stack.pop()  
            else:  # 스택이 비어있으면 여는 괄호가 필요함
                open_needed += 1  
    
    # 스택에 남아 있는 여는 괄호의 개수 (닫는 괄호로 추가 필요)
    close_needed = len(stack)
    
    # 앞과 뒤에 추가해야 할 괄호의 총 개수
    result = open_needed + close_needed
    return result

result = problem2(input)

assert result == 3  # 예상 결과와 비교
print("정답입니다.")
