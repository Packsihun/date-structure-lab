# 프로젝트 문제 1번
input = [10, 40, 30, 60, 30]

def problem1(input):
    # mean과 median 초기화
    mean = 0
    median = 0
    
    # 평균 계산: 주어진 수들의 합을 수의 개수로 나눈 값
    total = sum(input)  # 주어진 수들의 합 계산
    mean = total // len(input)  # 평균 계산
    
    # 중앙값 계산: 주어진 수들을 정렬하여 중간 위치에 있는 값
    sorted_input = sorted(input)  # 주어진 수들을 크기순으로 정렬
    median = sorted_input[len(input) // 2]  # 중앙값 계산
    
    # 결과 리스트에 평균과 중앙값 저장 후 반환
    result = [0, 0]  # 초기 결과 리스트를 생성하고 평균과 중앙값을 0으로 설정
    result[0] = mean  # 결과 리스트의 첫 번째 요소에 평균 값을 저장
    result[1] = median  # 결과 리스트의 두 번째 요소에 중앙값을 저장
    return result  # 결과 리스트를 반환

# 문제에서 주어진 예시와 결과가 일치하는지 확인하는 assert문
result = problem1(input)  # problem1 함수를 호출하여 결과를 result에 저장
assert result == [34, 30]  # 결과가 [34, 30]과 일치하는지 확인

# 결과가 일치하면 정답 메시지 출력
print("정답입니다.")  # 결과가 예상과 일치하면 "정답입니다." 메시지 출력
