# 프로젝트 문제 3번
input = [[4, 3, 2, 1],
         [0, 0, 0, 0],
         [0, 0, 9, 0],
         [1, 2, 3, 4]]
N = 4

forest = []

def problem3(input):
    bear_size = 2  # 곰의 초기 크기
    honeycomb_count = 0  # 먹은 벌집의 개수
    time = 0  # 경과 시간
    bear_x, bear_y = 0, 0  # 곰의 초기 위치

    # forest 리스트를 input 리스트로 초기화
    forest = [row[:] for row in input]
    
    # 곰의 초기 위치 찾기
    for i in range(N):
        for j in range(N):
            if forest[i][j] == 9:  # 곰의 위치를 찾으면
                bear_x, bear_y = i, j  # 위치 저장
                forest[i][j] = 0  # 곰의 위치를 빈칸으로 만듦
    print("곰의 초기 위치 x : {0}, y : {1}".format(bear_x, bear_y))  # 곰의 초기 위치 출력

    # 상하좌우 이동을 위한 방향 벡터
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    def bfs(bx, by):
        visited = [[False] * N for _ in range(N)]  # 방문 여부를 기록할 리스트
        queue = [(bx, by, 0)]  # BFS 탐색을 위한 큐 초기화 (x, y, 이동 시간)
        visited[bx][by] = True  # 초기 위치 방문 처리
        possible_targets = []  # 먹을 수 있는 벌집을 저장할 리스트

        while queue:
            x, y, dist = queue.pop(0)  # 큐에서 현재 위치와 거리를 꺼냄
            
            for dx, dy in directions:  # 상하좌우 이동
                nx, ny = x + dx, y + dy  # 새로운 위치 계산
                
                if 0 <= nx < N and 0 <= ny < N and not visited[nx][ny]:  # 유효한 위치인지 확인
                    if forest[nx][ny] <= bear_size:  # 곰이 지나갈 수 있는지 확인
                        visited[nx][ny] = True  # 방문 처리
                        if 0 < forest[nx][ny] < bear_size:  # 먹을 수 있는 벌집인지 확인
                            possible_targets.append((dist + 1, nx, ny))  # 먹을 수 있는 벌집 추가
                        queue.append((nx, ny, dist + 1))  # 큐에 새로운 위치 추가
        
        if not possible_targets:  # 먹을 수 있는 벌집이 없으면
            return None, None, None  # None 반환
        possible_targets.sort()  # 가능한 목표 정렬
        return possible_targets[0]  # 가장 가까운 목표 반환

    while True:
        dist, target_x, target_y = bfs(bear_x, bear_y)  # BFS 탐색으로 목표 찾기
        if target_x is None:  # 목표가 없으면
            break  # 반복문 종료
        
        bear_x, bear_y = target_x, target_y  # 곰의 위치 업데이트
        time += dist  # 경과 시간 업데이트
        honeycomb_count += 1  # 먹은 벌집의 개수 증가
        forest[bear_x][bear_y] = 0  # 먹은 벌집을 빈 칸으로 만듦
        
        if honeycomb_count == bear_size:  # 곰이 크기만큼 벌집을 먹었으면
            bear_size += 1  # 곰의 크기 증가
            honeycomb_count = 0  # 먹은 벌집의 개수 초기화

    return time  # 총 경과 시간 반환

result = problem3(input)  # 문제 해결 후 결과 저장

assert result == 14  # 결과 검증
print("정답입니다.")  # 정답 메시지 출력
